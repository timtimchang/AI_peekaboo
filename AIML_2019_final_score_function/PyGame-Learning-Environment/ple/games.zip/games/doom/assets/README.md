The cfg files and wad files were taken from ViZDoom.
Source: https://github.com/Marqt/ViZDoom
